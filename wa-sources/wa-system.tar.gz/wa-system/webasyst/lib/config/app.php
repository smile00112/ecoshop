<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.6.9',
    'critical'=>'1.6.7',
    'vendor' => 'webasyst',
);
