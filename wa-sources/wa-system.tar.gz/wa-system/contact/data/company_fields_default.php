<?php
return array (
  'name' => array (
      'required' => false,
  ),
  'company_contact_id' => array(),
  'company' => array (
        'required' => true,
      ),
  'email' => array (),
  'phone' => array (),
  'address' => array (),
  'url' => array (),
  'about' => array (),
  'categories' => array (),
);
// EOF