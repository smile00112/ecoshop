<?php

// Make sure webasyst app is loaded (required in frontend)
wa('webasyst');

class contactsBackendRegionsController extends webasystBackendRegionsController
{
    // Nothing to do!
}

