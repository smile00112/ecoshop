<?php

abstract class shopPlugin extends waPlugin
{

}
