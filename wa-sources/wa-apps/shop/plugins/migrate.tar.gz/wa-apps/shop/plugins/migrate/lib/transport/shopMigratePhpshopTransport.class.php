<?php

/**
 * Class shopMigratePhpshopTransport
 * @title PHPShop
 * @group YML
 */
class shopMigratePhpshopTransport extends shopMigrateYmlTransport
{

}
